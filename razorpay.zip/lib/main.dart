import 'package:flutter/material.dart';
import 'main_scaffold.dart';
import 'features/payment/services/local_storage_service.dart';
import 'features/payment/services/subscription_service.dart';
import 'features/payment/services/local_notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services
  final localStorageService = LocalStorageService();
  final localNotificationService = LocalNotificationService();
  final subscriptionService = SubscriptionService(
    localStorageService: localStorageService,
    localNotificationService: localNotificationService,
  );
  
  // Initialize local storage
  await localStorageService.initialize();
  
  // Initialize notifications
  await localNotificationService.initialize();
  
  // Resubscribe to pending orders
  final pendingOrders = await localStorageService.getPendingOrders();
  print('App initialization: Found ${pendingOrders.length} pending orders');
  
  for (final order in pendingOrders) {
    print('App initialization: Resubscribing to order ${order.orderId}');
    try {
      await subscriptionService.subscribeToOrder(order.orderId);
    } catch (e) {
      print('App initialization: Failed to resubscribe to order ${order.orderId}: $e');
      // Continue with other orders even if one fails
    }
  }
  
  print('App initialization: Resubscription complete');
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nourisha Pay',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const MainScaffold(),
    );
  }
}
