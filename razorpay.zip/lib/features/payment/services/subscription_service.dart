import 'dart:async';
import 'dart:convert';
import 'package:amplify_api/amplify_api.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'local_storage_service.dart';
import 'local_notification_service.dart';
import '../../../models/order_detail.dart';

/// Service for managing AppSync GraphQL subscriptions for real-time order updates
///
/// This service handles the lifecycle of subscriptions, including creation,
/// cancellation, and cleanup. It works with LocalStorageService to update
/// orders when subscription events arrive.
///
/// Key responsibilities:
/// - Subscribe to order updates via AppSync GraphQL
/// - Handle subscription events and update local storage
/// - Auto-cancel subscriptions when orders reach final status
/// - Implement retry logic for failed subscriptions
/// - Maintain map of active subscriptions for cleanup
/// - Trigger notifications when order status changes to paid/failed
class SubscriptionService {
  final LocalStorageService _localStorageService;
  final LocalNotificationService _localNotificationService;
  
  /// Map of orderId to active subscription
  final Map<String, StreamSubscription<GraphQLResponse<String>>> _activeSubscriptions = {};

  SubscriptionService({
    required LocalStorageService localStorageService,
    required LocalNotificationService localNotificationService,
  })  : _localStorageService = localStorageService,
        _localNotificationService = localNotificationService;

  /// Get count of active subscriptions (for debugging)
  int get activeSubscriptionCount => _activeSubscriptions.length;

  /// Subscribe to order updates for a specific orderId
  ///
  /// This method:
  /// 1. Cancels any existing subscription for the same orderId
  /// 2. Creates a new AppSync GraphQL subscription
  /// 3. Handles subscription events and updates local storage
  /// 4. Auto-cancels subscription when order reaches final status
  /// 5. Implements retry logic on failure (up to 3 attempts)
  ///
  /// Throws exception if subscription fails after all retry attempts.
  Future<void> subscribeToOrder(String orderId) async {
    // Cancel existing subscription for this orderId if any
    await cancelSubscription(orderId);

    // Implement retry logic (up to 3 attempts)
    int attempts = 0;
    const maxAttempts = 3;
    const retryDelay = Duration(seconds: 5);

    while (attempts < maxAttempts) {
      attempts++;
      
      try {
        print('SubscriptionService: Attempting to subscribe to order $orderId (attempt $attempts/$maxAttempts)');
        
        // Create GraphQL subscription query
        const subscriptionDocument = '''
          subscription OnOrderUpdate(\$orderId: ID!) {
            onOrderUpdate(orderId: \$orderId) {
              order_id
              razorpay_order_id
              amount
              currency
              status
              payment_id
              created_at
              updated_at
              is_synced
            }
          }
        ''';

        // Create subscription request
        final subscriptionRequest = GraphQLRequest<String>(
          document: subscriptionDocument,
          variables: {'orderId': orderId},
        );

        // Subscribe using Amplify API
        final operation = Amplify.API.subscribe(
          subscriptionRequest,
          onEstablished: () {
            print('SubscriptionService: Subscription established for $orderId');
          },
        );

        // Listen to subscription stream
        final subscription = operation.listen(
          (event) {
            _handleSubscriptionUpdate(orderId, event);
          },
          onError: (error) {
            print('SubscriptionService: Subscription error for $orderId: $error');
            // Don't retry here, let the outer retry logic handle it
          },
          onDone: () {
            print('SubscriptionService: Subscription completed for $orderId');
            _activeSubscriptions.remove(orderId);
          },
        );

        // Store subscription in active subscriptions map
        _activeSubscriptions[orderId] = subscription;
        
        print('SubscriptionService: Successfully subscribed to order $orderId');
        return; // Success, exit retry loop
        
      } catch (e) {
        print('SubscriptionService: Failed to subscribe to order $orderId (attempt $attempts/$maxAttempts): $e');
        
        if (attempts < maxAttempts) {
          print('SubscriptionService: Retrying in ${retryDelay.inSeconds} seconds...');
          await Future.delayed(retryDelay);
        } else {
          print('SubscriptionService: All retry attempts exhausted for order $orderId');
          throw Exception('Failed to subscribe to order $orderId after $maxAttempts attempts: $e');
        }
      }
    }
  }

  /// Handle subscription update event
  ///
  /// Parses the GraphQL response and updates local storage.
  /// Auto-cancels subscription if order reaches final status (paid or failed).
  /// Triggers notifications when order status changes to paid or failed.
  Future<void> _handleSubscriptionUpdate(
    String orderId,
    GraphQLResponse<String> event,
  ) async {
    try {
      print('SubscriptionService: Received update for order $orderId');
      
      // Parse the response data
      if (event.data == null) {
        print('SubscriptionService: No data in subscription update for $orderId');
        return;
      }

      // The event.data is a JSON string, parse it
      final data = event.data!;
      print('SubscriptionService: Raw subscription data: $data');
      
      // Parse JSON string to Map
      final Map<String, dynamic> jsonResponse = jsonDecode(data);
      
      // Extract the order data from the subscription response
      // AppSync returns data in format: { "onOrderUpdate": { ...orderFields } }
      final Map<String, dynamic>? orderJson = jsonResponse['onOrderUpdate'] as Map<String, dynamic>?;
      
      if (orderJson == null) {
        print('SubscriptionService: No onOrderUpdate data in response for $orderId');
        return;
      }
      
      // Parse to OrderDetail
      final orderData = OrderDetail.fromJson(orderJson);
      
      print('SubscriptionService: Parsed order data - status: ${orderData.status}, updatedAt: ${orderData.updatedAt}');
      
      // Get the previous order state to check for status changes
      final previousOrder = await _localStorageService.getOrder(orderId);
      
      // Update local storage (handles timestamp comparison)
      final updated = await _localStorageService.updateOrder(orderData);
      
      if (updated) {
        print('SubscriptionService: Successfully updated order $orderId with status ${orderData.status}');
        
        // Trigger notifications if status changed to paid or failed
        // Only trigger if previous status was pending or processing
        if (previousOrder != null && 
            (previousOrder.status == 'pending' || previousOrder.status == 'processing')) {
          
          if (orderData.status == 'paid' && !_localNotificationService.isAppInForeground) {
            print('SubscriptionService: Triggering payment success notification for $orderId');
            await _localNotificationService.showPaymentSuccessNotification(
              orderId: orderId,
              amount: orderData.amount,
            );
          } else if (orderData.status == 'failed' && !_localNotificationService.isAppInForeground) {
            print('SubscriptionService: Triggering payment failure notification for $orderId');
            await _localNotificationService.showPaymentFailureNotification(
              orderId: orderId,
              amount: orderData.amount,
            );
          }
        }
        
        // Auto-cancel subscription if order reached final status
        if (orderData.status == 'paid' || orderData.status == 'failed') {
          print('SubscriptionService: Order $orderId reached final status ${orderData.status}, cancelling subscription');
          await cancelSubscription(orderId);
        }
      } else {
        print('SubscriptionService: Update discarded for order $orderId (stale data)');
      }
      
    } catch (e) {
      print('SubscriptionService: Error handling subscription update for $orderId: $e');
    }
  }

  /// Cancel subscription for a specific orderId
  ///
  /// Removes the subscription from the active subscriptions map
  /// and cancels the underlying stream subscription.
  Future<void> cancelSubscription(String orderId) async {
    final subscription = _activeSubscriptions.remove(orderId);
    if (subscription != null) {
      await subscription.cancel();
      print('SubscriptionService: Cancelled subscription for $orderId');
    }
  }

  /// Cancel all active subscriptions
  ///
  /// Used during app shutdown or service disposal.
  Future<void> cancelAllSubscriptions() async {
    final orderIds = _activeSubscriptions.keys.toList();
    for (final orderId in orderIds) {
      await cancelSubscription(orderId);
    }
    print('SubscriptionService: Cancelled all ${orderIds.length} subscriptions');
  }

  /// Dispose and cleanup all resources
  ///
  /// Should be called when the service is no longer needed.
  void dispose() {
    // Cancel all subscriptions synchronously
    for (final subscription in _activeSubscriptions.values) {
      subscription.cancel();
    }
    _activeSubscriptions.clear();
    print('SubscriptionService: Disposed');
  }
}
