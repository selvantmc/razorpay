import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/payment_service.dart';
import '../services/backend_api_service.dart';
import '../models/payment_models.dart';

class RazorpayPosScreen extends StatefulWidget {
  const RazorpayPosScreen({super.key});

  @override
  State<RazorpayPosScreen> createState() => _RazorpayPosScreenState();
}

class _RazorpayPosScreenState extends State<RazorpayPosScreen> {
  final _amountController = TextEditingController();
  final _referenceController = TextEditingController();
  PaymentService? _paymentService;

  String _responseText = '';
  PaymentStatus _currentStatus = PaymentStatus.unknown;
  bool _isProcessing = false;
  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();
    _initializePaymentService();
  }

  Future<void> _initializePaymentService() async {
    try {
      // Check if running on web
      if (kIsWeb) {
        setState(() {
          _isInitializing = false;
          _responseText = 'Note: Razorpay Flutter SDK does not support web platform.\n\n'
              'To test payment functionality:\n'
              '1. Run on Android: flutter run -d android\n'
              '2. Run on iOS: flutter run -d ios\n\n'
              'The UI is functional, but payment processing requires a mobile platform.';
        });
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final backendApi = BackendApiService(
        baseUrl: 'https://rhqxsjqj11.execute-api.ap-south-1.amazonaws.com',
        useMockMode: false, // ✅ Using real AWS Lambda backend
      );

      setState(() {
        _paymentService = PaymentService(
          backendApi: backendApi,
          prefs: prefs,
        );
        _isInitializing = false;
        _responseText = '✅ Connected to AWS Backend\n\n'
            'Backend: AWS Lambda (ap-south-1)\n'
            'Ready to process payments via Razorpay\n\n'
            'Enter amount and click "Pay Now" to start';
      });
    } catch (e) {
      setState(() {
        _isInitializing = false;
        _responseText = 'Initialization error: $e';
      });
    }
  }

  Future<void> _handlePayNow() async {
    if (kIsWeb) {
      _showError('Payment processing is not available on web. Please run on Android or iOS.');
      return;
    }

    if (_paymentService == null) {
      _showError('Payment service not initialized');
      return;
    }

    final amountText = _amountController.text.trim();
    if (amountText.isEmpty) {
      _showError('Please enter amount');
      return;
    }

    final amount = int.tryParse(amountText);
    if (amount == null || amount <= 0) {
      _showError('Please enter valid amount');
      return;
    }

    setState(() {
      _isProcessing = true;
      _responseText = 'Initiating payment...';
    });

    try {
      // Amount in paise (multiply by 100)
      await _paymentService!.openCheckout(
        amount: amount * 100,
        reference: _referenceController.text.trim(),
      );

      // Wait for callback
      await Future.delayed(const Duration(seconds: 2));

      final result = _paymentService!.lastResult;
      if (result != null) {
        _displayResult(result);
      }
    } catch (e) {
      setState(() {
        _responseText = 'Error: $e';
        _currentStatus = PaymentStatus.failed;
      });
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  Future<void> _handleCheckStatus() async {
    if (kIsWeb) {
      _showError('Status check is not available on web. Please run on Android or iOS.');
      return;
    }

    if (_paymentService == null) {
      _showError('Payment service not initialized');
      return;
    }

    setState(() {
      _isProcessing = true;
      _responseText = 'Checking payment status...';
    });

    try {
      final statusResponse = await _paymentService!.checkStatus();
      _displayStatusResponse(statusResponse);
    } catch (e) {
      setState(() {
        _responseText = 'Error checking status: $e';
      });
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  void _displayResult(PaymentResult result) {
    setState(() {
      _currentStatus = result.status;
      _responseText = _formatJson(result.toJson());
    });
  }

  void _displayStatusResponse(PaymentStatusResponse response) {
    setState(() {
      _currentStatus = response.status;
      _responseText = _formatJson(response.toJson());
    });
  }

  String _formatJson(Map<String, dynamic> json) {
    // Pretty print JSON with indentation
    const encoder = JsonEncoder.withIndent('  ');
    return encoder.convert(json);
  }

  Color _getStatusColor() {
    switch (_currentStatus) {
      case PaymentStatus.success:
        return Colors.green;
      case PaymentStatus.failed:
        return Colors.red;
      case PaymentStatus.pending:
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Show loading indicator while initializing
    if (_isInitializing) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Nourisha POS – Payment'),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nourisha POS – Payment'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Amount input
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Amount (₹)',
                border: OutlineInputBorder(),
                prefixText: '₹ ',
              ),
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // Reference input
            TextField(
              controller: _referenceController,
              decoration: const InputDecoration(
                labelText: 'Order Reference (Optional)',
                border: OutlineInputBorder(),
              ),
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 24),

            // Pay Now button
            ElevatedButton(
              onPressed: _isProcessing ? null : _handlePayNow,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 20),
              ),
              child: _isProcessing
                  ? const CircularProgressIndicator()
                  : const Text(
                      'Pay Now',
                      style: TextStyle(fontSize: 24),
                    ),
            ),
            const SizedBox(height: 16),

            // Check Status button
            OutlinedButton(
              onPressed: _isProcessing ? null : _handleCheckStatus,
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text(
                'Check Payment Status',
                style: TextStyle(fontSize: 18),
              ),
            ),
            const SizedBox(height: 24),

            // Response panel
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: _getStatusColor(), width: 2),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[100],
                ),
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: Text(
                    _responseText.isEmpty
                        ? 'Response will appear here'
                        : _responseText,
                    style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _amountController.dispose();
    _referenceController.dispose();
    _paymentService?.dispose();
    super.dispose();
  }
}
